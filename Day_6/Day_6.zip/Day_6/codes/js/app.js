// functions in javascript
// function that is being used to run multiple lines of code grouped together
// function welcomeMsg () {
//     console.log("welcome to the world of js");
//     console.log("Programming is a fun game");
//     console.log("some more text");
// }

// welcomeMsg();


// function sumUp (a, b, c) {

//     let s = a + b + c;

//     console.log(s);

// }

// sumUp(1, 5, 7);


// function that returns a value
// function welcomeUser(username) {

//     return 'Hi ' + username;
// }

// // let msg = welcomeUser('test');

// console.log(welcomeUser('test'));



// IIFE ( Immediately Invoked Function expression )

// (function () {

//     console.log("printed from the function");

//     console.log('some more thinig is being printed here');

// })();




// Array
