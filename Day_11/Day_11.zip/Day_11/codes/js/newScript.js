const users = [
    {
        firstName : "test1",
        lastName  : "test 1-1",
        email     : "test1@test.com"
    },
    {
        firstName : "test 2",
        lastName  : "test 2-1",
        email     : "test2@test.com"
    }
];

users.forEach(function(user) {
    console.log(user.email);
});

// forEach
// const friends = ['ram', 'shyam', 'hari', 'sita', 'gita'];

// friends.forEach(function(friend) {
//     console.log(friend);
// });


