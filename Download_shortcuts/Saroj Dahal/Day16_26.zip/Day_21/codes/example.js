console.log("A");
// fetch()... //400
setTimeout(() => console.log("i am here"), 1000);
// --> Timer
console.log("C");
console.log("B");
