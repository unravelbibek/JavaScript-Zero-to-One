const fruits = ["Apple", "Mango"];

// fruits.forEach((value, index, array) => console.log(index, value));

// var doForEach = function (fruit, idx) {
//   console.log(fruit);
// };

// fruits.forEach(doForEach);

// for (let fruit of fruits) {
//   console.log(fruit);
// }
