// const numbers = [1, 2, 3];

// const squaredNumbers = numbers.map(function (value, index, array) {
//   return value * value;
// });

// const cubeNumbers = numbers.map((value) => value * value * value);

// console.log(cubeNumbers);

//[1,4,9]

// const users = [
//   {
//     id: 1,
//     name: "ABC",
//   },
//   {
//     id: 2,
//     name: "CDE",
//   },
// ];

// users.map((value, index, array) => {
//   console.log(value.id + " " + value.name);
// });

// const colors = ["Red", "Green", "Blue"];

// const colorList = colors.map((value) => {
//   //   console.log(array);
//   return `<p>I like ${value} color</p>`;
// });

// console.log(colorList);
