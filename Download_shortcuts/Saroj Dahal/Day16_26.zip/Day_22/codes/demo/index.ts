async function fetchSomeData(){

    const data = await fetch("https://");
    return data;
}