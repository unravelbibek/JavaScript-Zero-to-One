// function add(a, b, ...params) {
//   console.log(params);
//   var sum = a + b;

//   for (let i = 0; i < params.length; i++) {
//     sum += params[i];
//   }
//   return sum;
// }

// console.log(add(1, 2, 3, 4, 5, 6, 10, 12));

const message = "Hello there";

console.log(...message);
