// const planets1 = ["Sun", "Moon", "Jupiter", "Saturn"];
// const shadowPlanets = ["Rahu", "Ketu"];

// const allPlanets = [...planets1, ...shadowPlanets, "Venus", "Neptune"];
// const [a, b, c, d = "ABC"] = shadowPlanets;

// const [planet1, planet2, ...rest] = ["Sun", "Moon", "Jupiter", "Saturn"];

// console.log(planet1, planet2, rest);
