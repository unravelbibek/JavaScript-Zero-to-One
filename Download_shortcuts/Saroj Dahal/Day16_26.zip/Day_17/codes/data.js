function add(a, b) {
  // console.log(user);
  return a + b;
}

var user = {
  id: 1,
  name: "Pratik",
};

const studentList = ["ABC", "Stuti", "Rounak"];

class Product {
  getProduct() {
    console.log("Product list");
  }
}

const text = "Hello";
// export = {Product};

module.exports = {studentList};
// export {add};

// add()
