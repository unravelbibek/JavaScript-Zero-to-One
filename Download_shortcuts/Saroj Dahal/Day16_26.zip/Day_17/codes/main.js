const {studentList} = require("./data.js");
// import adder from "./data.js";

// console.log(adder(1, 2));
console.log(studentList);

// var p = new Product();
// p.getProduct();

// import React, {useState, useEffect} from "react";
