// var id = 2;
// var user = {
//   id: 1,
//   name: {
//     fullName: "Saroj",
//     middleName: "NA",
//     lastName: "Dahal",
//   },
//   profilePicture: "https://abc.com/1/a.jpg",
//   doSomething() {
//     return "did Something";
//   },
// };

// const {
//   name: {fullName},
// } = user;
// console.log(fullName);

// console.log(user.doSomething());

// var id = user.id;
// var id = user["id"];
// var name = user["name"];
// var profilePicture = user.profilePicture;

// const {id = 2, name, profilePicture, location = "Kathmandu"} = user;
// const {
//   name: {fullName},
// } = user;

// console.log(fullName);

// var user = {
//   id: 2,
//   name: "ABC",
//   profilePicture: "https://abc.com/1/a.jpg",
// };

// var userExtraInfo = {
//   location: "Kathmandu",
//   dob: "1998 August 6",
// };

// var updatedUser = {
//   ...user,
//   ...userExtraInfo,
//   phone: "984664534543",
//   location: "Damauli",
// };
// console.log(updatedUser);
