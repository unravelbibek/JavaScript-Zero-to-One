// function add(a, b) {
//   //action..
//   return a + b;
// }

// var addFxn = function (a, b) {
//   return a + b;
// };

var helloFxn = () => "Hello";

// var helloFxn = function (){

//     return "Hello";
// }
console.log(helloFxn());
