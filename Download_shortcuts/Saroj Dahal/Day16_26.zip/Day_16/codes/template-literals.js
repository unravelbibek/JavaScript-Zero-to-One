let name = "ABC";
let age = 12;

// console.log("hello " + name + " and age is " + age + "\n\n hello");
// console.log(`hello ${name} and age is  ${age}

// hello`);

// console.log(`hello ${name} and age is ${age}`);

// console.log(`${1 + 2}`);

// console.log(`hello "${name}" and age is '${age}'`);

// function abc() {
//   return 1;
// }

// console.log(`Number is ${abc()}`);

console.log(`${age > 18 ? "Can vote" : "Cant vote"}`);

// ?:
// (condition)?true:false;
// (age>18)?console.log("can vote"):console.log("cant vote");
// if(age>18){
//     console.log("can vote");
// }
// else {
//     console.log("cant vote")
// }

//naming Conventions.
//function name : doSomethingExtra //camelCase.
// class name   : Student, RegisterStudent
// variables    : studentMarks, isAvailable.
//constants     : API_URL, ACCESS_TOKEN,
