// function add(a, b) {
//   return a + b;
// }

// var data = "abc";
// console.log(typeof add);
// console.log(add instanceof Object);
// console.log(data instanceof String);

// var myAdder = function (a, b) {
//   return a + b;
// };
// myAdder.info = "Hello";

// console.log(myAdder.info);

// //higher order function.
// function test(fxn) {
//   return fxn;
// // }

// function test2() {
//   console.log("test 2");
// }

// test(test2);

// //higher order function
// function outer(a, b) {
//   console.log(a, b);
//   function inner(c, d) {
//     return c;
//   }

//   return inner;
// }

// // console.log(outer(1, 2)(3, 4));
// // outer()();
