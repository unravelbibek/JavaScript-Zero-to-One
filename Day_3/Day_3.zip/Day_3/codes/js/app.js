// Data types in javascript
// Primitives
// String

// let mobileName;
// string
// mobileName = 'Samsung';

// console.log(mobileName);

// number
// mobileName = 123.222;

// console.log(mobileName);

// boolean
// let iAmAProgrammer = true;

// iAmAProgrammer = false;

// console.log(typeof iAmAProgrammer);


// null
// let totalOnlineUsersCount = null;

// console.log(typeof totalOnlineUsersCount);


// undefined
// let users = undefined;

// console.log(typeof users);


// let num1 = 123.22;

// BigInt
// console.log(Number.MAX_SAFE_INTEGER);

// let num1 = BigInt(1);

// let num1 = 1n;

// console.log(typeof num1);


// let a = 10;

// let b = 20;

// console.log(a / b);

// console.log( 1n + 2 );




// Objects
// let mobile = {
//     color : 'blue',
//     price : '15000',
//     brand : 'Lenovo',
//     os    : 'Android'
// };

// let sujal = {
//     myFullName : 'sujal khatiwada',
//     age        : 22,
//     myDetails  : function() {
//         console.log("It\"s fun to learn js");
//     }
// };

// console.log(sujal);

// console.log(sujal.myFullName);

// sujal.myDetails();



// String concatenation

let firstName = 'sujal';
let lastName  = 'khatiwada';

console.log( firstName + ' ' + lastName );

let firstNum = prompt("Enter first number");
firstNum     = parseInt(firstNum);

let secondNum = prompt("Enter second number");
secondNum     = parseInt(secondNum);

alert(firstNum + secondNum);

