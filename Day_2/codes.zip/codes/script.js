// var
// var myName = "test user";

// myName = "another name";

// console.log(myName);

// var firstName = "test";
// var lastName  = "test";

// console.log(firstName, lastName);


// let
// ES6
// let country = "Nepal";

// console.log(country);


// intro to window object
// var favBook = "The Harry Potter";

// let country = "Nepal";

// ES6 - ES2015
// Javascript is an implementation


// constant

// const myFavColor = "red";

// myFavColor = "123";

// console.log(myFavColor);


// variables naming conventions
// var myFavColor = "red";
// // camelCase

// // snake case
// var my_fav_color = "teal";

// console.log(my_fav_color);


// let myFavColor = "red";

// let myFavColor = "teal";

// console.log(myFavColor);
// var myName;



// var myName = "test user";


// var myName = "another name";

// console.log(myName);


var name = "no name";

